module.exports = {
modul: {
	axios: require('axios'),
	boom: require('@hapi/boom'),
	baileys: require('@whiskeysockets/baileys'), 
	chalk: require('chalk'),
	cheerio: require('cheerio'),
	child_process: require('child_process'),
	fs: require('fs'),
	fetch: require('node-fetch'),
	FormData: require('form-data'),
	FileType: require('file-type'),
	process: require('process'),
	PhoneNumber: require('awesome-phonenumber')
}
}
/*
    CREDIST !!!
        Hallo Sis, here are the names who have been registered in creating/helping in the development of this script

        *BIG TAHNKS TO*

        > Hw Mods [ Base ]
        > Rerez Hosting [ Developer ]
        > HyuuXyz [My Team]
        > KyuuRzy [ My Team ]
        > CeliaOffc [ My Team]
        > DiiOffc [ My Team ]

        d above is developer
        
    SAYA SANGAT BERTERIMA KASIH JIKA KALIAN MEMBIARKAN CREDIT INI TANMPA MENGHAPUS ATAU MENGGANTI NYA 
    TOLONG HARGAI YAA 

*/